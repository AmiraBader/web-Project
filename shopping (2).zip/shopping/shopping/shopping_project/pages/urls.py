from django.urls import path
from . import views

urlpatterns = [
    path("",views.home,name="home"),
    path("login",views.login,name="login"),
    path("signup",views.signup,name="signup"),
    path("home",views.home,name="home"),
    path("product",views.product,name="product"),
    path("view_product",views.view_product,name="view_product"),
    path("basket",views.basket,name="basket"),
    path("order",views.order,name="order"),
    path("logout",views.logout,name="logout"),
    path("add",views.add,name="add"),
    path("empty",views.empty,name="empty"),
    path("confirm",views.confirm,name="confirm"),
    path("find",views.find,name="find")








]