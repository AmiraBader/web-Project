from django.shortcuts import render
from django.http import HttpResponse
from .models import Users,Product,Basket,Orders


def login(request):
    if request.method == "POST":
        uname = request.POST["uname"]
        password = request.POST["psw"]
        user = Users.objects.filter(username=uname,password = password)
        if user:
            request.session["u_id"] = user[0].id 
            products = Product.objects.filter(price__lte=40) 
            if products:
                return render(request,'pages/home.html',{"products":products})
            else:
                 return render(request,'pages/home.html',{"message":"Sorry there is no offer with price less than 40"})

        else:
            return render(request,'pages/login.html')
    else:
        return render(request,'pages/login.html')
    


def logout(request):
    del request.session["u_id"] #delet user from session
    return render(request,'pages/home.html')



def signup(request):
    if request.method == "POST":
        name = request.POST["name"]#key
        uname = request.POST["uname"]#key
        password = request.POST["psw"]#key
        user = Users(
            name =  name,
            username =  uname,
            password =  password
            )#but in database
        user.save()
        user = Users.objects.filter(username=uname,password = password)
        request.session["u_id"] = user[0].id 
        return render(request,'pages/login.html')
    else:
        return render(request,'pages/signup.html')




def home(request):
    products = Product.objects.filter(price__lte=40)
    if products:
        return render(request,'pages/home.html',{"products":products})
    else:
        return render(request,'pages/home.html',{"message":"Sorry there is no offer with price less than 40"})





def product(request):
    products = Product.objects.select_related('c_id').all()#bring all product from all catigory
    return render(request,'pages/product.html',{"products":products})




def view_product(request):
    id = request.GET["id"]
    product = Product.objects.filter(id=id)#filter will return a list 
    return render(request,'pages/view_product.html',{"product":product[0]})#the list only contine one product




def basket(request):
    u_id = request.session["u_id"]#basket for the user in the session
    basket = Basket.objects.select_related('p_id').filter(u_id=u_id)#bring all product in DB then filter for this user
    total_cost = 0
    for b in basket:
        total_cost += b.p_id.price #calculate total
    return render(request,'pages/basket.html',{"basket":basket,"total_cost":total_cost})




def order(request):
    u_id = request.session["u_id"]#order for the user in the session
    orders = Orders.objects.filter(u_id=u_id)#bring all order for this user
    return render(request,'pages/order.html',{"orders":orders})




def add(request):
    id = request.GET["id"]
    u_id = request.session["u_id"]#bring who is in the session
    product = Product.objects.filter(id=id)
    user = Users.objects.filter(id=u_id)
    basket = Basket(
            p_id =  product[0],
            u_id =  user[0]
            )
    basket.save()
    products = Product.objects.select_related('c_id').all()
    return render(request,'pages/product.html',{"products":products,"added":"yes"})




def empty(request):
    u_id = request.session["u_id"]#bring who is in the session
    Basket.objects.filter(u_id=u_id).delete() 
    return render(request,'pages/basket.html',{"empty":"yes"})



def confirm(request):#save all basket info in order table
    u_id = request.session["u_id"]#bring who is in the session
    user = Users.objects.filter(id=u_id)
    basket = Basket.objects.filter(u_id=u_id)
    total_cost = 0
    for b in basket:
        total_cost += b.p_id.price
    order = Orders(
            total_cost=total_cost,
            u_id=user[0]
        )
    order.save()
    Basket.objects.filter(u_id=u_id).delete()# empty basket after confirm order
    return render(request,'pages/basket.html',{"confirm":"yes"})





def find(request):
    name = request.GET["name"]#bring name user write it in the search
    product = Product.objects.select_related('c_id').filter(name=name)
    if product:
        return render(request,'pages/find.html',{"product":product[0]})
    else:
        return render(request,'pages/find.html')
        

