from django.db import models
class Users(models.Model):
    id= models.AutoField(primary_key = True)
    name =  models.CharField(max_length = 50)
    username =  models.CharField(max_length = 30)
    password =  models.CharField(max_length = 10)

class Category(models.Model):
    id= models.AutoField(primary_key = True)
    name =  models.CharField(max_length = 50)

class Product(models.Model):
    id= models.AutoField(primary_key = True)
    name =  models.CharField(max_length = 70)
    description =  models.TextField(default = "")
    price =  models.DecimalField(max_digits = 20,decimal_places=2)
    c_id = models.ForeignKey(Category, null=True, on_delete=models.CASCADE)

class Basket(models.Model):
    id= models.AutoField(primary_key = True)
    p_id = models.ForeignKey(Product, null=True, on_delete=models.CASCADE)
    u_id = models.ForeignKey(Users, null=True, on_delete=models.CASCADE)

class Orders(models.Model):
    id= models.AutoField(primary_key = True)
    total_cost =  models.DecimalField(max_digits = 20,decimal_places=2)
    u_id = models.ForeignKey(Users, null=True, on_delete=models.CASCADE)
